#ifdef __OBJC__
#import <UIKit/UIKit.h>
#endif


FOUNDATION_EXPORT double OnfidoVersionNumber;
FOUNDATION_EXPORT const unsigned char OnfidoVersionString[];

