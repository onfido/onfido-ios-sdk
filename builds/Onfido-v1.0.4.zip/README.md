# Onfido Example

This iOS application is an example app consuming the Onfido SDK for iOS.

## Getting started

Run the following script from the root directory to get up and running:

```
./bin/initialise.sh
```

## Manual Setup

Before setting up make sure you have met the requirements.

### Requirements

- Cocoapods v1.1.1

### Project setup

Run the following command to retrieve the Example app dependencies on the root directory of the Example app:

```sh
pod install
```

Once installation has finished you can open the project on Xcode, alternatively you can use the following shortcut on the root directory of the Example app:

```sh
open -a Xcode Onfido.xcworkspace
```
