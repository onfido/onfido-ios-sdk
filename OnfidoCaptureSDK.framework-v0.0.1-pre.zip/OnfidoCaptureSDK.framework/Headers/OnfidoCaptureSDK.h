//
//  OnfidoCaptureSDK.h
//  OnfidoCaptureSDK
//
//  Created by Tiago Pinto on 09/06/2016.
//  Copyright © 2016 Onfido. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OnfidoCaptureSDK.
FOUNDATION_EXPORT double OnfidoCaptureSDKVersionNumber;

//! Project version string for OnfidoCaptureSDK.
FOUNDATION_EXPORT const unsigned char OnfidoCaptureSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OnfidoCaptureSDK/PublicHeader.h>
